fx_version 'adamant'
games { 'gta5' }

author 'KotzEimer'
name 'KotzEimer_enginetoggle'
description 'EngineToggle for Vehicles'
version '3.7.1'

lua54 'yes'

shared_script {
    'config.lua',
	'translation.lua'
}

client_scripts {
	'client.lua',
}

server_scripts {
	'server.lua',
}