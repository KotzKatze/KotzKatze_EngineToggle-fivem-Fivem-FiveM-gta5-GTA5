Toggle engine with key M
script by:
KotzKatze
sorry bc of the name firstly i wanted to name my name kotzeimer sorry 